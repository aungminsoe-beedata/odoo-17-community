from odoo import models, fields

    
class DeliveryOrder(models.Model):
  
    _inherit = 'delivery.carrier'
    test = fields.Char(sting = 'hh test')
    
    


class CustomSaleOrder(models.Model):
    _inherit = 'sale.order'

    def shipping_wizard(self):
        print('call wizard---------------------------------------------------------------000000000000000000000000000000')
        # Call the original method from sale.order
        return self.action_open_delivery_wizard()


   