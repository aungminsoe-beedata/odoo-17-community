/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";

publicWidget.registry.websiteSaleDelivery = publicWidget.registry.websiteSaleDelivery.extend({
    start: async function () {
        this._super.apply(this, arguments);
        this._bindButtonClick();        
    },
    _bindButtonClick: function() {
        const $showButton = $('#show_button');
        const $hideButton = $('#hide_button');
        const $toggleText = $('#toggle_text');

        if ($showButton.length && $hideButton.length && $toggleText.length) {
            $showButton.on('click', function() {
                $toggleText.show();
            });

            $hideButton.on('click', function() {
                $toggleText.hide();
            });
        }
    },
});
