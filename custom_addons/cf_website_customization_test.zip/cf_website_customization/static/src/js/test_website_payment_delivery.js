/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";

publicWidget.registry.websiteSaleDelivery = publicWidget.registry.websiteSaleDelivery.extend({
    start: async function () {
        this._super.apply(this, arguments);
        this._bindButtonClick();
    },
    _bindButtonClick: function() {
        // Bind click event to dynamically created buttons
        $(document).on('click', '.dynamic-button', function() {
            const code = $(this).data('code');
            
            // Toggle the display of the container
            const $textDisplay = $('#text_display');
            
            if ($textDisplay.is(':visible')) {
                // Hide the text if already visible
                $textDisplay.hide();
            } else {
                // Show the text and update its content if hidden
                $('#display_text').text('Button with code ' + code + ' clicked');
                $textDisplay.show();
            }
        });
    },
});
