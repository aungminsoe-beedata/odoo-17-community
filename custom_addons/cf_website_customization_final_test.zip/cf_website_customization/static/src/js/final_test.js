/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";

publicWidget.registry.websiteSaleDelivery = publicWidget.registry.websiteSaleDelivery.extend({
    start: async function () {
        this._super.apply(this, arguments);
        this._bindButtonClick();
        this._bindLiClick();
    },
    _bindButtonClick: function() {
        // Bind click event to dynamically created buttons
        $(document).on('click', '.dynamic-button', function() {
            const buttonId = this.id; // Get the button's ID
            // const $listItem = $('#list_item_' + buttonId); // Get the matching list item by ID
            //     console.log('hello',buttonId)
            document.querySelectorAll('.list-group-item').forEach(item => {
                item.style.display = (item.id === buttonId) ? 'block' : 'none';
            });
        });
    },


    _bindLiClick: function() {
        // Bind click event to list items
        $(document).on('click', '.list-group-item', (event) => {
            // Reset the color of all list items
            $('.list-group-item').css('background-color', '');
    
            // Set the background color of the clicked item to green
            $(event.currentTarget).css('background-color', '#4CAF50');
            // $(event.currentTarget).css('color', 'white'); // Optional: change text color for better contrast
    
            // Optional: Log the ID of the clicked item
            const liId = event.currentTarget.id; // Get the list item's ID
            
        });
    }
    
});
