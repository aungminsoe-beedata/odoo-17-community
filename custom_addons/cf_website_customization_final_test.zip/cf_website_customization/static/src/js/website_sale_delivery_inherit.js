/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";

publicWidget.registry.websiteSaleDelivery = publicWidget.registry.websiteSaleDelivery.extend({
    /**
     * Overriding the start method to initialize the select event listener
     */
    start: async function () {
        this._super.apply(this, arguments);

        // Bind the select change event
        this._bindDeliveryMethodSelect();
        this._bindDeliveryButtonClick();
     
        
    },

    /**
     * Bind the change event on the delivery method select
     */
    _bindDeliveryMethodSelect: function() {
        const $selectElement = $('#delivery_method_select');
        if ($selectElement.length) {
            $selectElement.on('change', this._onDeliveryMethodChange.bind(this));
        }
    },

    /**
     * Event handler for select change
     */
    _onDeliveryMethodChange: function (event) {
        const selectedDeliveryId = $(event.target).val();
        console.log("Selected delivery ID:", selectedDeliveryId);

        // Automatically click the button with the matching delivery ID
        this._autoClickButton(selectedDeliveryId);
    },

    /**
     * Automatically click the button with the specified delivery ID
     */
    _autoClickButton: function(deliveryId) {
        const $button = $(`.delivery-button[data-product-id="${deliveryId}"]`);
        if ($button.length) {
            $button.find('input.o_order_location_address').prop('checked', true); // Mark the radio as checked
            $button.click(); // Trigger the button click event
        }
    },

    /**
     * Bind the click event on delivery buttons
     */
    _bindDeliveryButtonClick: function() {
        const $buttons = $('.delivery-button');
        if ($buttons.length) {
            $buttons.off('click').on('click', this._onDeliveryButtonClick.bind(this));
        }
    },

    /**
     * Event handler for button click
     */
    _onDeliveryButtonClick: function(event) {
        const $button = $(event.currentTarget);
        const $input = $button.find('input.o_order_location_address');
        const inputValue = $input.val();

        console.log("Button clicked with value:", inputValue);

        // Add any additional logic you need to handle
    },

    
      
});
