/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";

publicWidget.registry.websiteSaleDelivery = publicWidget.registry.websiteSaleDelivery.extend({
    /**
     * Overriding the start method to initialize the select event listener
     */
    start: async function () {
        this._super.apply(this, arguments);

        // Bind the select change event
        this._bindDeliveryMethodSelect();
        this._bindDeliveryButtonClick();
    },

    /**
     * Bind the change event on the delivery method select
     */
    _bindDeliveryMethodSelect: function() {
        const $selectElement = $('#delivery_method_select');
        if ($selectElement.length) {
            $selectElement.on('change', this._onDeliveryMethodChange.bind(this));
        }
    },

    /**
     * Event handler for select change
     */
    _onDeliveryMethodChange: function (event) {
        const selectedDeliveryId = $(event.target).val();
        console.log("Selected Delivery Product ID:", selectedDeliveryId);

        // You can also add custom logic here
    },
     /**
     * Bind the click event on delivery buttons
     */
     _bindDeliveryButtonClick: function() {
        const $buttons = $('.delivery-button');
        $buttons.on('click', this._onDeliveryButtonClick.bind(this));
    },

    /**
     * Event handler for button click
     */
    _onDeliveryButtonClick: function(event) {
        const $button = $(event.currentTarget);
        const productId = $button.data('product-id');
        console.log("This button clicked. Value is delivery.product_id.id:", productId);

        // Add any additional logic you need to handle
    },
});
