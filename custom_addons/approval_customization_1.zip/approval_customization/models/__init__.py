# -*- coding: utf-8 -*-
#schoolpj17
from . import models
from . import RFQ
from . import class_name_creation
from . import approval_request_user #approval_request is only in approval module in the state

from . import rfq_request_approval
from . import stock_picking_view
from . import purchase_received_waiting