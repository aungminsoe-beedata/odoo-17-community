from odoo import models, fields, api

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    receipt_state = fields.Selection([
        ('all_received', 'All Received'),
        ('waiting', 'Waiting')
    ], string="Receipt Status", compute="_compute_receipt_state", store=True)

    @api.depends('order_line.qty_received', 'order_line.product_qty')
    def _compute_receipt_state(self):
        for order in self:
            all_received = True
            for line in order.order_line:
                if line.qty_received < line.product_qty:
                    all_received = False
                    break
            order.receipt_state = 'all_received' if all_received else 'waiting'
