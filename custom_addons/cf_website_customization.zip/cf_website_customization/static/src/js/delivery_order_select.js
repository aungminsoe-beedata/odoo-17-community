/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";

publicWidget.registry.websiteSaleDelivery = publicWidget.registry.websiteSaleDelivery.extend({
    start: async function () {
        this._super.apply(this, arguments);
        this._bindButtonClick();
        this._bindLiClick();
        

    },
    _bindButtonClick: function() {
        // Bind click event to dynamically created buttons
        $(document).on('click', '.dynamic-button', function() {
            const buttonId = this.id;
            $('.dynamic-button').each(function() {
                this.style.backgroundColor = ''; // Remove inline background color
                this.style.color = ''; // Optionally remove text color
            });
            this.style.backgroundColor = '#4CAF50';
            document.querySelectorAll('.list-group-item').forEach(item => {
                item.style.display = (item.id === buttonId) ? 'block' : 'none';
            });
        });
    },
    _bindLiClick: function() {
        // Bind click event to list items
        $(document).on('click', '.list-group-item', (event) => {
            $('.list-group-item').css('background-color', '');
            $(event.currentTarget).css('background-color', '#4CAF50');
            const liId = event.currentTarget.id; // Get the list item's ID
            
        });
    },
    /**
     * @private
     * @param {Event} ev
     */
    _onCarrierClick: async function (ev) {
        const radio = ev.currentTarget.closest('.o_delivery_carrier_select').querySelector(
            'input[type="radio"]'
        );
        if (radio.checked && !this._shouldDisplayPickupLocations(ev) && !this.forceClickCarrier) {
            return;
        }
        this.forceClickCarrier = false;
        this._disablePayButton();
        this._showLoading(radio);
        radio.checked = true;
        await this._onClickShowLocations(ev);
        await this._handleCarrierUpdateResult(radio);
        this._disablePayButtonNoPickupPoint(ev);
    },
    
});

